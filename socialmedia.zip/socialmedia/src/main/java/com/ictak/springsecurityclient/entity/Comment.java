package com.ictak.springsecurityclient.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "comment")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long comment_id;

//    @OneToOne(mappedBy = "Post", cascade = CascadeType.ALL)
    private Long post_id;     //    ER relationship
//    @ManyToOne(cascade = CascadeType.ALL)
//    @JoinColumn(name="user_id")
    private Long commenter_id;     //    ER relationship

    @Column(name = "comment_text")
    private String comment_text;

    @Column(name = "Type_Of_Comment")
    private String Type_Of_Comment;

}
