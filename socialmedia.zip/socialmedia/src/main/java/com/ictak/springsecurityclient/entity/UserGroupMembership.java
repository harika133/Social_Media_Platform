package com.ictak.springsecurityclient.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Table(name = "user_group_membership")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class UserGroupMembership {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long user_id;

    @Column(name = "joined_group_on")
    private Date joined_group_on;

    @Column(name = "Left_group_on")
    private Date Left_group_on;
    @Column(name ="active_or_passsive_member")
    private Boolean active_or_passsive_member;
}
