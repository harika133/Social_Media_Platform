package com.ictak.springsecurityclient.service;

import com.ictak.springsecurityclient.entity.Post;

public interface PostServices {

    Post savePost(Post post);

    Post getPostById(Long postId);

    String deletePostById(Long postId);
}

