package com.ictak.springsecurityclient.service;

import com.ictak.springsecurityclient.entity.Post;
import com.ictak.springsecurityclient.repository.PostRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service

public class PostServicesImpl implements PostServices {

    private final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private PostRepository postRepository;

    @Override
    public Post savePost(Post post) {
        logger.info("\n\n\nLog: Post Details Saved!\n\n\n");
        return postRepository.save(post);
    }

    @Override
    public Post getPostById(Long postId) {
        logger.info("\n\n\nLog: Post Details Displayed!\n\n\n");
        return postRepository.findById(postId).get();
    }




    @Override
    public String deletePostById(Long postId) {
        postRepository.deleteById(postId);
        logger.info("\n\n\nLog: Post Details Deleted!\n\n\n");
        return "Successfully Created";
    }
}