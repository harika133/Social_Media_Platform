package com.ictak.springsecurityclient.controller;

import com.ictak.springsecurityclient.entity.Post;
import com.ictak.springsecurityclient.service.PostServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class PostController {


    @Autowired
    private PostServices postServices;

    @PostMapping("/posts")
    public Post savePost(@RequestBody Post post){
        return postServices.savePost(post);
    }

    @GetMapping("/posts/{id}")
    public Post getPostById(@PathVariable("id") Long postId){
        return postServices.getPostById(postId);
    }


    @DeleteMapping("/posts/{id}")
    public void deletePostById(@PathVariable("id") Long postId) {
        postServices.deletePostById(postId);
    }

}
