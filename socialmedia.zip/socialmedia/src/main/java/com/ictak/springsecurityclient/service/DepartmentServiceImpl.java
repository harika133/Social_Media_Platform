package com.ictak.springsecurityclient.service;

import com.ictak.springsecurityclient.entity.Department;
import com.ictak.springsecurityclient.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Objects;

@Service

public class DepartmentServiceImpl implements DepartmentServices {

    private final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private DepartmentRepository departmentRepository;

    @Override
    public Department saveDepartment(Department department) {
        logger.info("\n\n\nLog: Department Details Saved!\n\n\n");
        return departmentRepository.save(department);
    }

    @Override
    public Department getDepartmentById(Long departmentId) {
        logger.info("\n\n\nLog: Department Details Displayed!\n\n\n");
        return departmentRepository.findById(departmentId).get();
    }

    @Override
    public Department updateDepartment(Long departmentId, Department department) {

        Department deptDB = departmentRepository.findById(departmentId).get();

        if (Objects.nonNull(department.getDepartmentName()) && !"".equalsIgnoreCase(department.getDepartmentName())) {
            deptDB.setDepartmentName(department.getDepartmentName());
        }

        if (Objects.nonNull(department.getDepartmentCode()) && !"".equalsIgnoreCase(department.getDepartmentCode())) {
            deptDB.setDepartmentCode(department.getDepartmentCode());
        }

        if (Objects.nonNull(department.getDepartmentAddress()) && !"".equalsIgnoreCase(department.getDepartmentAddress())) {
            deptDB.setDepartmentAddress(department.getDepartmentAddress());
        }
        logger.info("\n\n\nLog: Department Details Saved!\n\n\n");
        return departmentRepository.save(deptDB);
    }

    @Override
    public String deleteDepartmentById(Long departmentId) {
        departmentRepository.deleteById(departmentId);
        logger.info("\n\n\nLog: Department Details Deleted!\n\n\n");
        return("Successfully Created");
    }
}