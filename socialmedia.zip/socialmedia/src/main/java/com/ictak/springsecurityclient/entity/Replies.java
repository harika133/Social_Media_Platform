package com.ictak.springsecurityclient.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Replies")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class Replies {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long Replay_id;


//    @OneToMany(mappedBy = "Likes",cascade = CascadeType.ALL)
    private Long parent_comment_id;     //    ER relationship
//    @ManyToOne(cascade = CascadeType.ALL)
//    @JoinColumn(name = "user_id")
    private Long replied_by_id;     //    ER relationship

    @Column(name = "reply_text")
    private String reply_text;

}
