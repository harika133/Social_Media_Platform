package com.ictak.springsecurityclient.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@Entity
@Table(name = "user_page_follow")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class UserPageFollow {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long user_id;



    @Column(name = "followed_on")
    private Date followed_on;

    @Column(name = "unfollowed_on")
    private Date unfollowed_on;

    @Column(name="active_or_passive_member")
    private Boolean active_or_passive_member;
}
