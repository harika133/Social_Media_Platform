package com.ictak.springsecurityclient.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Likes")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class Likes {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long Like_id;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @ManyToOne(cascade = CascadeType.ALL)
//    @JoinColumn(name = "parent_comment_id")
    private Long Liked_on_id;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @ManyToOne(cascade = CascadeType.ALL)
//    @JoinColumn(name = "user_id")
    private Long Liked_by_id;

    @Column(name = "Liked_on_type")
    private String Liked_on_type;

    @Column(name = "reaction_type")
    private String reaction_type;
}
