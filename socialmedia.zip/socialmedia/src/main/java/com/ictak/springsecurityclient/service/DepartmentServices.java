package com.ictak.springsecurityclient.service;
import com.ictak.springsecurityclient.entity.Department;

public interface DepartmentServices {

    Department saveDepartment(Department department);

    Department getDepartmentById(Long departmentId);

    Department updateDepartment(Long departmentId, Department department);

    String deleteDepartmentById(Long departmentId);

}

