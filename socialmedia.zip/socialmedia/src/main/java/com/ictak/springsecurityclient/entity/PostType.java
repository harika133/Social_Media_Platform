package com.ictak.springsecurityclient.entity;

public enum PostType {
	TEXT,
	IMAGE,
	VIDEO
}
