package com.ictak.springsecurityclient.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Post")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter

public class Post {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long post_id;

    //@ManyToMany(mappedBy = "User", cascade = CascadeType.ALL)
    private long author_id;

    @Column(name = "post_type")
    private PostType post_type;


}
